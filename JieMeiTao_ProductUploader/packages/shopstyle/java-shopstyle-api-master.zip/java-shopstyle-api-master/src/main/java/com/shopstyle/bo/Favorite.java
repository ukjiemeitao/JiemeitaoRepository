package com.shopstyle.bo;

public class Favorite {

	private String id;
	private Product product;

	public String getId() {
		return id;
	}

	public Product getProduct() {
		return product;
	}

}
