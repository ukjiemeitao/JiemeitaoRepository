package com.shopstyle.api;

import com.shopstyle.bo.Size;

public class SizeListResponse
{
    private Size[] sizes;

    public Size[] getSizes()
    {
        return sizes;
    }
}
